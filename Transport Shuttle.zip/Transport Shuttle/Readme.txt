Here is my futuristic transport shuttle design.
http://wp.me/P3dmoi-1qk/

I modeled, textured and rigged this sci-fi shuttle in Blender from 31.10.2011 to 12.11.2011.
https://3dhaupt.com/futuristic-transport-shuttle-work-in-progress-videos-31-10-2011-12-11-2011/

3d and animation preview on Sketchfab
https://sketchfab.com/models/2292ce758e114a5f87626d81404d5f44

Test in Unity
https://www.youtube.com/watch?v=rIm3NHT1pck


Some cool projects where this futuristic transport shuttle has found a use:

Celflux Animated Trailer Full 2016 (HD) by GemGfx
https://www.youtube.com/watch?v=QAY8jzYW2xc&feature=youtu.be

Landing Scene - Wip -Controller test� UE4 by Mauro
https://www.youtube.com/watch?v=8E9Mf8jpY7c

Mars by Kiwi Robbie
https://www.youtube.com/watch?v=hdUCDWoS2LE


Animated Yes
Rigged Yes
Lowpoly (game-ready) Yes
Geometry Subdivision ready
Polygons 16,343
Vertices 18,360
Textures Yes
Materials Yes
UV Mapping Yes
Unwrapped UVs Non-overlapping

Feel free to use it for your projects.

Demo-Video: https://www.youtube.com/watch?v=FDI68lEZ4ZU
Animated 3d-preview on Sketchfab: https://sketchfab.com/models/2292ce758e114a5f87626d81404d5f44

Homepage: http://3dartdh.wordpress.com/
Contact me: https://3dartdh.wordpress.com/contact/
Sketchfab: https://sketchfab.com/dennish2010
YouTube: https://www.youtube.com/user/DennisH2010

